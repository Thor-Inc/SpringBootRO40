package pl.sdacademy.SpringBootRO40;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRo40Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRo40Application.class, args);
	}

}
