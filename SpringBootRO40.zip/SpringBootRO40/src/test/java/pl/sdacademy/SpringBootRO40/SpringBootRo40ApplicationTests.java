package pl.sdacademy.SpringBootRO40;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRo40ApplicationTests {

	@Test
	void contextLoads() {
	}

}
